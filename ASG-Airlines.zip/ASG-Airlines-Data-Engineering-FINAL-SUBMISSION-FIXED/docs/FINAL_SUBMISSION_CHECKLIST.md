# ASG Airlines — Final Submission Checklist

## Prepared package
- [x] Reproducible Python ingestion/validation/transformation pipeline
- [x] Overnight/cross-day duration handling
- [x] Quarantine with explicit reason codes
- [x] Reconciliation control
- [x] Curated analytical outputs with airline/route/date keys
- [x] Synthetic public-safe sample data
- [x] SQL schema and analytics queries aligned to curated keys
- [x] Executable notebook
- [x] 9 automated tests
- [x] Architecture, data-flow and data-model diagrams
- [x] Consistent technical documentation
- [x] Power BI DAX measures and theme
- [x] Corrected Power BI reference designs
- [x] Raw PII excluded from public package
- [x] Python cache files excluded

## Still required in Power BI Desktop
- [ ] Load curated CSVs and quarantine data
- [ ] Rename tables as documented
- [ ] Set field data types
- [ ] Create the documented 1:* relationships
- [ ] Add DAX measures
- [ ] Build four dashboard pages
- [ ] Verify KPI cards against the measured pipeline outputs
- [ ] Save `powerbi/ASG_Airlines.pbix` locally
- [ ] Capture genuine screenshots from Power BI Desktop
- [ ] Replace reference PNGs with genuine screenshots if the competition requires them

## Final safety checks
- [ ] Do not commit `data/raw/`
- [ ] Do not publish passenger names, email, phone, Aadhaar, passport or emergency-contact data
- [ ] Do not commit passwords, API keys or `.env` files
- [ ] Run `python run_pipeline.py`
- [ ] Run `pytest -q`
- [ ] Confirm reconciliation PASS
