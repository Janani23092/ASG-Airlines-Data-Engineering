# ASG Airlines — Power BI Build Guide

The package contains a reproducible Python pipeline and Power BI-ready CSV outputs. The `.pbix` is intentionally not included because it must be created and saved in Power BI Desktop.

## 1. Load these tables

| File | Table name | Use |
|---|---|---|
| `data/curated/fact_flights.csv` | `FactFlights` | Main flight fact |
| `data/curated/dim_airline.csv` | `DimAirline` | Airline dimension |
| `data/curated/dim_route.csv` | `DimRoute` | Route dimension |
| `data/curated/dim_date.csv` | `DimDate` | Departure-date dimension |
| `data/curated/dq_metrics.csv` | `DQMetrics` | Pipeline DQ score components |
| `data/curated/record_quality_summary.csv` | `RecordQuality` | Valid vs invalid counts |
| `data/quarantine/flights_quarantine.csv` | `Quarantine` | Rejected flight records |
| `data/curated/fact_bookings.csv` | `FactBookings` | Booking extension |
| `data/curated/fact_payments.csv` | `FactPayments` | Payment/revenue extension |
| `data/curated/dim_passenger.csv` | `DimPassenger` | Masked/synthetic passenger attributes |

## 2. Data types

- `FactFlights[departure_time]`, `[arrival_time]`, `[arrival_time_adjusted]` → Date/Time
- `FactFlights[duration_minutes]` → Decimal number
- `FactFlights[is_overnight]` → True/False
- `FactFlights[anomaly_flag]`, `[duration_status]` → Text
- `FactFlights[airline_key]`, `[route_key]`, `[date_key]` → Text
- `DimDate[date]` → Date
- `FactBookings[booking_date]` → Date/Time
- `FactPayments[amount]` → Decimal number
- `DQMetrics[dq_score]`, `[completeness]`, `[validity]`, `[uniqueness]`, `[consistency]` → Decimal number
- `RecordQuality[record_count]` → Whole number

## 3. Relationships

Create these relationships with single-direction filtering from dimension/parent to fact:

| From | To | Cardinality |
|---|---|---|
| `DimAirline[airline_key]` | `FactFlights[airline_key]` | 1:* |
| `DimRoute[route_key]` | `FactFlights[route_key]` | 1:* |
| `DimDate[date_key]` | `FactFlights[date_key]` | 1:* |
| `FactFlights[flight_key]` | `FactBookings[flight_key]` | 1:* |
| `FactBookings[booking_id]` | `FactPayments[booking_id]` | 1:* |

Do not create many-to-many relationships for these tables.

## 4. Measures

Use `powerbi/ASG_Airlines_DAX_Measures.dax`. The Data Quality Score is intentionally read from `DQMetrics[dq_score]`, so the Power BI card matches the pipeline's documented 30/30/20/20 formula rather than using a second, different formula.

## 5. Page 1 — Executive Operations

KPI cards: Total Flights, Average Flight Duration, Overnight %, Anomaly %, Data Quality Score.

Visuals:
- Donut: `FactFlights[airline]` + `[Total Flights]`
- Bar: `FactFlights[route]` + `[Total Flights]`, Top N 10
- Column: `FactFlights[airline]` + `[Average Flight Duration]`
- Slicers: airline, source, destination, route

## 6. Page 2 — Route Performance

- Bar: Route vs Total Flights
- Bar/column: Route vs Average Flight Duration
- Bar: Route vs Anomaly %
- Matrix: Route, Total Flights, Average Flight Duration, Anomaly %
- Slicers: airline, source, destination

## 7. Page 3 — Airline Performance

- Column: Airline vs Total Flights
- Bar: Airline vs Average Flight Duration
- Bar: Airline vs Anomaly %
- Donut: Airline share of network
- Matrix: Airline, Flights, Avg Duration, Overnight %, Anomaly %

## 8. Page 4 — Data Quality Command Center

KPI cards: Input Flights, Valid Records, Quarantined Flights, Anomaly %, DQ Score.

Visuals:
- Donut: `RecordQuality[status]` + `RecordQuality[record_count]` — expected sample split is 99 VALID / 1 INVALID
- Column: `FactFlights[anomaly_flag]` + `[Total Flights]`
- Bar/table: `Quarantine[reason_description]` + record count
- Table: flight_id, airline, source, destination, reason_description

Do not label the valid-record donut as 100% when the input contains a quarantined row.

## 9. Current sample validation targets

These are measured from the synthetic sample only and should be treated as a smoke-test target. If the competition workbook is run locally, replace them with the measured competition-data values.

| Metric | Sample target |
|---|---:|
| Input Flights | 100 |
| Curated Flights | 99 |
| Quarantined Flights | 1 |
| Average Flight Duration | 140.93 min |
| Overnight Flights | 29 |
| Overnight Share | 29.29% |
| Anomalies | 9 |
| Anomaly Rate | 9.09% |
| DQ Score | 99.00% |
| Reconciliation | PASS |

## 10. Save and capture

Save the report as `powerbi/ASG_Airlines.pbix`. Capture screenshots directly from Power BI Desktop after the report is built. The PNGs currently in this package are **reference designs**, not evidence that a `.pbix` was created.
